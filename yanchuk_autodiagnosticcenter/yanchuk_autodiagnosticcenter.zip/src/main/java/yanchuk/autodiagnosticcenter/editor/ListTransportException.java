package yanchuk.autodiagnosticcenter.editor;

public class ListTransportException extends Exception {

    public ListTransportException(String message, Throwable exc) {
        super(message, exc);
    }
}
