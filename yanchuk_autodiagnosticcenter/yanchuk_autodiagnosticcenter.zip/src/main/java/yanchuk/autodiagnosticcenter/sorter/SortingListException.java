package yanchuk.autodiagnosticcenter.sorter;

public class SortingListException extends Exception {

    public SortingListException(final String message, final Throwable exc) {
        super(message, exc);
    }
}
