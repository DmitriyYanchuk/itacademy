package yanchuk.autodiagnosticcenter.sorter;

public class SortingReaderException extends Exception {

    public SortingReaderException(final String message, final Throwable exc) {
        super(message, exc);
    }
}
