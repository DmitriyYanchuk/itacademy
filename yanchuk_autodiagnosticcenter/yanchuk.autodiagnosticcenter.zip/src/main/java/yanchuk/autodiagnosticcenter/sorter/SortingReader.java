package yanchuk.autodiagnosticcenter.sorter;

import java.util.List;

public interface SortingReader {

    List<String> read(List<String> list) throws SortingReaderException;
}
