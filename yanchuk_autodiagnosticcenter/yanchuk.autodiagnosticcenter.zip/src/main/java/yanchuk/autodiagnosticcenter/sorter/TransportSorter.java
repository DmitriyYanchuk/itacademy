package yanchuk.autodiagnosticcenter.sorter;

import java.util.*;

public class TransportSorter implements SortingReader {

    private static int SORTING_TYPE;
    private int sortingOrder;

    public TransportSorter() {
        final Scanner scan = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("Select a sort type \n 1 - Car type \n 2 - Car model \n 3 - Maintenance cost");
            final int sortingType = scan.nextInt();
            switch (sortingType) {
                case 1 -> exit = true;
                case 2 -> exit = true;
                case 3 -> exit = true;
                default -> System.out.println("Please enter correct values");
            }

            if (exit) {
                System.out.println("Select a sort order \n 1 - Direct \n 2 - Reverse");
                final int sortingOrder = scan.nextInt();
                switch (sortingOrder) {
                    case 1 -> exit = true;
                    case 2 -> exit = true;
                    default -> {
                        exit = false;
                        System.out.println("Please enter correct values");
                    }
                }

                this.sortingOrder = sortingOrder;
                this.SORTING_TYPE = sortingType;
            }
        }
    }

    @Override
    public final List<String> read(List<String> list) throws SortingReaderException {
        try {
            Comparator<String> comparator = Comparator.comparing(TransportSorter::getType);
            if (sortingOrder == 2) {
                comparator = comparator.reversed();
            }
            return list.stream()
                    .sorted(comparator)
                    .toList();

        } catch (final RuntimeException exc) {
            throw new SortingReaderException("Sorting error", exc);
        }
    }

    private static String getType(final String transport) {
        final String[] parts = transport.split("\\s\\|\\s");
        final String type = parts[SORTING_TYPE - 1];
        return type;
    }
}